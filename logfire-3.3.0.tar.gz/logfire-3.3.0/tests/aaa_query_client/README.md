This folder starts with `aaa_` in order to make sure these tests run first.

I don't know why, but they don't pass when they aren't the first tests to run.
Maybe it's related to instrumenting httpx in some of the tests?
