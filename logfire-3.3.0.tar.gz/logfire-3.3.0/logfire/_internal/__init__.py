"""Internal Logfire logic.

We use the `_internal` module to discourage imports from outside the package,
and thereby avoid causing breaking changes when refactoring the package.
"""
